#include "Collider.h"

//bool Collider::CollidesWith(Collider& other, CollisionManifold& out)
//{
//	return false;
//}
//
//bool Collider::CollidesWith(SphereCollider& other, CollisionManifold& out)
//{
//	return false;
//}
